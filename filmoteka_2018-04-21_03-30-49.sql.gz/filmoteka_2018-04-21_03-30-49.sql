#SXD20|20011|50637|70107|2018.04.21 03:30:49|filmoteka|0|1|1|
#TA films`1`16384
#EOH

#	TC`films`utf8_general_ci	;
CREATE TABLE `films` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `genre` varchar(255) NOT NULL DEFAULT 'без жанра',
  `year` int(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`films`utf8_general_ci	;
INSERT INTO `films` VALUES 
(10,'Ледниковый период','Мультик',2015,'./images/70974736.jpg.jpg')	;
